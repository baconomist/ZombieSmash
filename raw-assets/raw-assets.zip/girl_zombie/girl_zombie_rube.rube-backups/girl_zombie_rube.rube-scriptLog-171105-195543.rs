//Restarted script log at 11/05/17 19:55:43
