//Restarted script log at 11/06/17 20:20:04
