//Restarted script log at 11/05/17 18:37:49
