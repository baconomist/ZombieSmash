//Restarted script log at 11/18/17 20:35:11
