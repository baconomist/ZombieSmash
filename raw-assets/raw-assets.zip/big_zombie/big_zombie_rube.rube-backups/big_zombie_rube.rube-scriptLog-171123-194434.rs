//Restarted script log at 11/23/17 19:44:34
