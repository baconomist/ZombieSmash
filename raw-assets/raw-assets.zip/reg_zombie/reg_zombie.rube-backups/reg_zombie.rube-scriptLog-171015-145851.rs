//Started script log at 10/15/17 14:58:27

getBody(3).select();
getBody(3).deselect();
getBody(3).select();
getFixture(19).select();
getFixture(19).deselect();
getBody(3).deselect();
getBody(3).select();
getBody(3).deselect();
getBody(3).select();
getBody(3).deselect();
getBody(2).select();
