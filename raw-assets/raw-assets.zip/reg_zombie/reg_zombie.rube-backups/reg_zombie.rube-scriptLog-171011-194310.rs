//Restarted script log at 10/11/17 19:43:10
