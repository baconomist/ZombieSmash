//Restarted script log at 10/21/17 21:54:05
