//Restarted script log at 11/05/17 15:37:10
getBody(1).select();
getBody(1).deselect();
getBody(3).select();
addImage(7, '{"body":null,"center":{"x":"3ED99BE1","y":"3EF5FFC8"},"file":"C:/Users/Lucas/Desktop/Projects/Android/ZombieSmash/android/assets/zombies/reg_zombie/reg_zombie.png","filter":1,"opacity":0.5,"scale":1}');
getBody(3).deselect();
getImage(7).select();
getImage(7).setCenter(1.45901,0.323042);
setCursor(0.495487, 0.00977464);
getImage(7).setCenter(1.26939,0.301575);
getImage(7).setCenter(0.202647,0.783283);
getImage(7).setAngle(1.57214);
getImage(7).setCenter(1.49425,0.718882);
getImage(7).setCenter(1.61589,2.42194);
getImage(7).setCenter(0.918216,1.42014);
getBody(1).select();
getBody(2).select();
getBody(3).select();
getBody(4).select();
getBody(5).select();
getBody(6).select();
setCursor(0.00174462, 0.00261896);
getJoint(1).setLocalAnchorB(-0.155774,-0.0083723);
getImage(1).setCenter(7.20546e-07,-1.22549e-07);
getImage(1).setScale(0.149235);
getBody(1).setPosition(0.887777,0.913068);
{
	fixture _rube_redoFixture = getFixture(2);
	_rube_redoFixture.setVertex(0,0.179676,-0.0260993);
	_rube_redoFixture.setVertex(1,0.170352,-0.00792271);
	_rube_redoFixture.setVertex(2,0.087157,0.0464927);
	_rube_redoFixture.setVertex(3,-0.0325808,0.0379141);
	_rube_redoFixture.setVertex(4,-0.0219059,-0.0558127);
	_rube_redoFixture.setVertex(5,0.0605335,-0.0623524);
	_rube_redoFixture.setVertex(6,0.102539,-0.0640849);
	_rube_redoFixture.setVertex(7,0.131436,-0.0574433);
}
{
	fixture _rube_redoFixture = getFixture(1);
	_rube_redoFixture.setVertex(0,-0.14728,0.0752734);
	_rube_redoFixture.setVertex(1,-0.180838,0.0752734);
	_rube_redoFixture.setVertex(2,-0.195986,0.062587);
	_rube_redoFixture.setVertex(3,-0.180838,0.0559594);
}
{
	fixture _rube_redoFixture = getFixture(4);
	_rube_redoFixture.setVertex(0,0.21702,0.0281982);
	_rube_redoFixture.setVertex(1,0.203912,0.0552322);
	_rube_redoFixture.setVertex(2,0.121182,0.0603583);
	_rube_redoFixture.setVertex(3,0.170352,-0.00792271);
	_rube_redoFixture.setVertex(4,0.197619,-0.00815535);
	_rube_redoFixture.setVertex(5,0.216961,0.00373024);
}
{
	fixture _rube_redoFixture = getFixture(3);
	_rube_redoFixture.setVertex(0,0.170352,-0.00792271);
	_rube_redoFixture.setVertex(1,0.121182,0.0603583);
	_rube_redoFixture.setVertex(2,0.087157,0.0464927);
}
{
	fixture _rube_redoFixture = getFixture(8);
	_rube_redoFixture.setVertex(0,-0.180838,0.0559594);
	_rube_redoFixture.setVertex(1,-0.213697,0.0326267);
	_rube_redoFixture.setVertex(2,-0.216785,0.00740057);
	_rube_redoFixture.setVertex(3,-0.207318,0.00268072);
}
{
	fixture _rube_redoFixture = getFixture(5);
	_rube_redoFixture.setVertex(0,0.179676,-0.0260993);
	_rube_redoFixture.setVertex(1,0.131436,-0.0574433);
	_rube_redoFixture.setVertex(2,0.1594,-0.0637361);
	_rube_redoFixture.setVertex(3,0.17245,-0.0549958);
}
{
	fixture _rube_redoFixture = getFixture(7);
	_rube_redoFixture.setVertex(0,-0.0325808,0.0379141);
	_rube_redoFixture.setVertex(1,-0.14728,0.0752734);
	_rube_redoFixture.setVertex(2,-0.180838,0.0559594);
	_rube_redoFixture.setVertex(3,-0.207318,0.00268072);
	_rube_redoFixture.setVertex(4,-0.210522,-0.027149);
	_rube_redoFixture.setVertex(5,-0.19179,-0.0538306);
}
{
	fixture _rube_redoFixture = getFixture(6);
	_rube_redoFixture.setVertex(0,-0.0219059,-0.0558127);
	_rube_redoFixture.setVertex(1,-0.0325808,0.0379141);
	_rube_redoFixture.setVertex(2,-0.19179,-0.0538306);
	_rube_redoFixture.setVertex(3,-0.169652,-0.0659492);
	_rube_redoFixture.setVertex(4,-0.10813,-0.0752716);
	_rube_redoFixture.setVertex(5,-0.0745719,-0.0752716);
}
getJoint(2).setLocalAnchorB(-0.168731,0.00767111);
getImage(5).setCenter(1.58281e-07,-4.00268e-08);
getImage(5).setScale(0.149235);
getBody(2).setPosition(0.323211,0.910166);
{
	fixture _rube_redoFixture = getFixture(15);
	_rube_redoFixture.setVertex(0,-0.180839,0.0559602);
	_rube_redoFixture.setVertex(1,-0.213698,0.0326262);
	_rube_redoFixture.setVertex(2,-0.216786,0.00739974);
	_rube_redoFixture.setVertex(3,-0.207317,0.0026803);
}
{
	fixture _rube_redoFixture = getFixture(16);
	_rube_redoFixture.setVertex(0,-0.147281,0.075274);
	_rube_redoFixture.setVertex(1,-0.180839,0.0752736);
	_rube_redoFixture.setVertex(2,-0.195986,0.0625881);
	_rube_redoFixture.setVertex(3,-0.180839,0.0559602);
}
{
	fixture _rube_redoFixture = getFixture(13);
	_rube_redoFixture.setVertex(0,-0.0219052,-0.0558106);
	_rube_redoFixture.setVertex(1,-0.0325817,0.0379145);
	_rube_redoFixture.setVertex(2,-0.191792,-0.0538314);
	_rube_redoFixture.setVertex(3,-0.169654,-0.0659488);
	_rube_redoFixture.setVertex(4,-0.10813,-0.0752709);
	_rube_redoFixture.setVertex(5,-0.0745723,-0.0752701);
}
{
	fixture _rube_redoFixture = getFixture(14);
	_rube_redoFixture.setVertex(0,-0.0325817,0.0379145);
	_rube_redoFixture.setVertex(1,-0.147281,0.075274);
	_rube_redoFixture.setVertex(2,-0.180839,0.0559602);
	_rube_redoFixture.setVertex(3,-0.207317,0.0026803);
	_rube_redoFixture.setVertex(4,-0.210522,-0.0271481);
	_rube_redoFixture.setVertex(5,-0.191792,-0.0538314);
}
{
	fixture _rube_redoFixture = getFixture(12);
	_rube_redoFixture.setVertex(0,0.179674,-0.0260984);
	_rube_redoFixture.setVertex(1,0.131436,-0.0574429);
	_rube_redoFixture.setVertex(2,0.1594,-0.0637344);
	_rube_redoFixture.setVertex(3,0.172449,-0.0549957);
}
{
	fixture _rube_redoFixture = getFixture(10);
	_rube_redoFixture.setVertex(0,0.170354,-0.0079224);
	_rube_redoFixture.setVertex(1,0.121181,0.0603596);
	_rube_redoFixture.setVertex(2,0.0871569,0.0464929);
}
{
	fixture _rube_redoFixture = getFixture(11);
	_rube_redoFixture.setVertex(0,0.21702,0.0281989);
	_rube_redoFixture.setVertex(1,0.20391,0.0552318);
	_rube_redoFixture.setVertex(2,0.121181,0.0603596);
	_rube_redoFixture.setVertex(3,0.170354,-0.0079224);
	_rube_redoFixture.setVertex(4,0.197618,-0.00815406);
	_rube_redoFixture.setVertex(5,0.216961,0.00373076);
}
{
	fixture _rube_redoFixture = getFixture(9);
	_rube_redoFixture.setVertex(0,0.179674,-0.0260984);
	_rube_redoFixture.setVertex(1,0.170354,-0.0079224);
	_rube_redoFixture.setVertex(2,0.0871569,0.0464929);
	_rube_redoFixture.setVertex(3,-0.0325817,0.0379145);
	_rube_redoFixture.setVertex(4,-0.0219052,-0.0558106);
	_rube_redoFixture.setVertex(5,0.060532,-0.0623514);
	_rube_redoFixture.setVertex(6,0.102538,-0.0640844);
	_rube_redoFixture.setVertex(7,0.131436,-0.0574429);
}
getJoint(6).setLocalAnchorB(-0.246079,-0.0496413);
getImage(6).setCenter(-2.96014e-08,-1.21653e-08);
getImage(6).setScale(0.530149);
getBody(3).setPosition(0.565823,1.22953);
{
	fixture _rube_redoFixture = getFixture(18);
	_rube_redoFixture.setVertex(0,0.252308,-0.14844);
	_rube_redoFixture.setVertex(1,0.239499,-0.0540882);
	_rube_redoFixture.setVertex(2,0.20849,-0.0837089);
	_rube_redoFixture.setVertex(3,0.20666,-0.12033);
	_rube_redoFixture.setVertex(4,0.224908,-0.163251);
}
{
	fixture _rube_redoFixture = getFixture(27);
	_rube_redoFixture.setVertex(0,0.228199,0.0307189);
	_rube_redoFixture.setVertex(1,0.201868,0.100934);
	_rube_redoFixture.setVertex(2,0.157984,0.152718);
	_rube_redoFixture.setVertex(3,0.093035,0.207574);
	_rube_redoFixture.setVertex(4,-0.122082,0.176971);
	_rube_redoFixture.setVertex(5,-0.0194194,-0.264953);
}
{
	fixture _rube_redoFixture = getFixture(25);
	_rube_redoFixture.setVertex(0,-0.0194194,-0.264953);
	_rube_redoFixture.setVertex(1,-0.122082,0.176971);
	_rube_redoFixture.setVertex(2,-0.263007,-0.0704592);
	_rube_redoFixture.setVertex(3,-0.245754,-0.134287);
	_rube_redoFixture.setVertex(4,-0.217339,-0.17499);
	_rube_redoFixture.setVertex(5,-0.0983019,-0.231492);
}
{
	fixture _rube_redoFixture = getFixture(26);
	_rube_redoFixture.setVertex(0,0.239499,-0.0540882);
	_rube_redoFixture.setVertex(1,0.228199,0.0307189);
	_rube_redoFixture.setVertex(2,-0.0194194,-0.264953);
	_rube_redoFixture.setVertex(3,0.0263303,-0.253215);
	_rube_redoFixture.setVertex(4,0.0613282,-0.224278);
}
{
	fixture _rube_redoFixture = getFixture(23);
	_rube_redoFixture.setVertex(0,0.093035,0.207574);
	_rube_redoFixture.setVertex(1,0.0248218,0.219423);
	_rube_redoFixture.setVertex(2,-0.119641,0.20911);
	_rube_redoFixture.setVertex(3,-0.122082,0.176971);
}
{
	fixture _rube_redoFixture = getFixture(24);
	_rube_redoFixture.setVertex(0,-0.122082,0.176971);
	_rube_redoFixture.setVertex(1,-0.156888,0.169504);
	_rube_redoFixture.setVertex(2,-0.20538,0.116733);
	_rube_redoFixture.setVertex(3,-0.261086,0.0273179);
	_rube_redoFixture.setVertex(4,-0.263007,-0.0704592);
}
{
	fixture _rube_redoFixture = getFixture(22);
	_rube_redoFixture.setVertex(0,0.0248218,0.219423);
	_rube_redoFixture.setVertex(1,0.0138233,0.24312);
	_rube_redoFixture.setVertex(2,-0.045613,0.262739);
	_rube_redoFixture.setVertex(3,-0.0882084,0.248057);
	_rube_redoFixture.setVertex(4,-0.119641,0.20911);
}
{
	fixture _rube_redoFixture = getFixture(20);
	_rube_redoFixture.setVertex(0,0.263088,-0.0491511);
	_rube_redoFixture.setVertex(1,0.24873,0.000877298);
	_rube_redoFixture.setVertex(2,0.239499,-0.0540882);
}
{
	fixture _rube_redoFixture = getFixture(21);
	_rube_redoFixture.setVertex(0,0.24873,0.000877298);
	_rube_redoFixture.setVertex(1,0.228199,0.0307189);
	_rube_redoFixture.setVertex(2,0.239499,-0.0540882);
}
{
	fixture _rube_redoFixture = getFixture(19);
	_rube_redoFixture.setVertex(0,0.20849,-0.0837089);
	_rube_redoFixture.setVertex(1,0.0613282,-0.224278);
	_rube_redoFixture.setVertex(2,0.115855,-0.225019);
	_rube_redoFixture.setVertex(3,0.165006,-0.200992);
	_rube_redoFixture.setVertex(4,0.194847,-0.160618);
	_rube_redoFixture.setVertex(5,0.20666,-0.12033);
}
{
	fixture _rube_redoFixture = getFixture(17);
	_rube_redoFixture.setVertex(0,-0.20538,0.116733);
	_rube_redoFixture.setVertex(1,-0.233905,0.0988497);
	_rube_redoFixture.setVertex(2,-0.261086,0.0273179);
}
getJoint(1).setLocalAnchorA(0.146698,-0.102078);
getJoint(2).setLocalAnchorA(0.135757,0.13861);
getJoint(4).setLocalAnchorA(-0.243873,0.0601487);
getJoint(5).setLocalAnchorA(-0.245011,-0.11181);
getJoint(6).setLocalAnchorA(0.223598,0.0247257);
getImage(2).setCenter(-6.82557e-09,-1.39467e-07);
getImage(2).setScale(0.419983);
getBody(4).setPosition(0.629926,0.757997);
{
	fixture _rube_redoFixture = getFixture(33);
	_rube_redoFixture.setVertex(0,0.248623,-0.0781832);
	_rube_redoFixture.setVertex(1,-0.130885,0.159563);
	_rube_redoFixture.setVertex(2,-0.251427,-0.16262);
	_rube_redoFixture.setVertex(3,-0.151004,-0.176693);
	_rube_redoFixture.setVertex(4,0.0804735,-0.151382);
	_rube_redoFixture.setVertex(5,0.194732,-0.110894);
}
{
	fixture _rube_redoFixture = getFixture(32);
	_rube_redoFixture.setVertex(0,-0.130885,0.159563);
	_rube_redoFixture.setVertex(1,-0.184957,0.139612);
	_rube_redoFixture.setVertex(2,-0.265552,0.0679072);
	_rube_redoFixture.setVertex(3,-0.27322,-0.0262475);
	_rube_redoFixture.setVertex(4,-0.251427,-0.16262);
}
{
	fixture _rube_redoFixture = getFixture(30);
	_rube_redoFixture.setVertex(0,0.248623,-0.0781832);
	_rube_redoFixture.setVertex(1,0.194732,-0.110894);
	_rube_redoFixture.setVertex(2,0.215339,-0.108786);
}
{
	fixture _rube_redoFixture = getFixture(31);
	_rube_redoFixture.setVertex(0,0.255352,-0.00592006);
	_rube_redoFixture.setVertex(1,0.247952,0.0674604);
	_rube_redoFixture.setVertex(2,0.214445,0.130453);
	_rube_redoFixture.setVertex(3,0.173344,0.147877);
	_rube_redoFixture.setVertex(4,0.0911679,0.167318);
	_rube_redoFixture.setVertex(5,-0.0466853,0.17418);
	_rube_redoFixture.setVertex(6,-0.130885,0.159563);
	_rube_redoFixture.setVertex(7,0.248623,-0.0781832);
}
{
	fixture _rube_redoFixture = getFixture(28);
	_rube_redoFixture.setVertex(0,-0.184957,0.139612);
	_rube_redoFixture.setVertex(1,-0.221592,0.13883);
	_rube_redoFixture.setVertex(2,-0.251905,0.116115);
	_rube_redoFixture.setVertex(3,-0.265552,0.0679072);
}
{
	fixture _rube_redoFixture = getFixture(29);
	_rube_redoFixture.setVertex(0,-0.151004,-0.176693);
	_rube_redoFixture.setVertex(1,-0.251427,-0.16262);
	_rube_redoFixture.setVertex(2,-0.23053,-0.185511);
	_rube_redoFixture.setVertex(3,-0.192106,-0.189203);
}
getJoint(5).setLocalAnchorB(0.239846,0.0388406);
getImage(4).setCenter(-1.41473e-08,2.31698e-08);
getImage(4).setScale(0.223318);
getBody(5).setPosition(0.780576,0.27314);
{
	fixture _rube_redoFixture = getFixture(41);
	_rube_redoFixture.setVertex(0,0.260285,0.063497);
	_rube_redoFixture.setVertex(1,0.0757194,-0.074315);
	_rube_redoFixture.setVertex(2,0.114228,-0.0759357);
	_rube_redoFixture.setVertex(3,0.146435,-0.0686028);
	_rube_redoFixture.setVertex(4,0.222398,-0.0411046);
	_rube_redoFixture.setVertex(5,0.239922,-0.0237973);
	_rube_redoFixture.setVertex(6,0.25286,0.0155906);
}
{
	fixture _rube_redoFixture = getFixture(42);
	_rube_redoFixture.setVertex(0,0.260285,0.063497);
	_rube_redoFixture.setVertex(1,0.254499,0.0986373);
	_rube_redoFixture.setVertex(2,0.243181,0.108669);
	_rube_redoFixture.setVertex(3,0.198168,0.0975709);
	_rube_redoFixture.setVertex(4,0.157496,0.0804798);
	_rube_redoFixture.setVertex(5,0.0917279,0.0365623);
	_rube_redoFixture.setVertex(6,0.0757194,-0.074315);
}
{
	fixture _rube_redoFixture = getFixture(39);
	_rube_redoFixture.setVertex(0,0.0917279,0.0365623);
	_rube_redoFixture.setVertex(1,-0.00946623,0.0255964);
	_rube_redoFixture.setVertex(2,-0.0666888,-0.0604808);
	_rube_redoFixture.setVertex(3,0.0757194,-0.074315);
}
{
	fixture _rube_redoFixture = getFixture(40);
	_rube_redoFixture.setVertex(0,-0.00946623,0.0255964);
	_rube_redoFixture.setVertex(1,-0.0994646,0.0281926);
	_rube_redoFixture.setVertex(2,-0.101466,-0.0506777);
	_rube_redoFixture.setVertex(3,-0.0666888,-0.0604808);
}
{
	fixture _rube_redoFixture = getFixture(38);
	_rube_redoFixture.setVertex(0,-0.0994646,0.0281926);
	_rube_redoFixture.setVertex(1,-0.124614,0.0430526);
	_rube_redoFixture.setVertex(2,-0.138136,0.0360215);
	_rube_redoFixture.setVertex(3,-0.147171,-0.0517695);
	_rube_redoFixture.setVertex(4,-0.132619,-0.0620356);
	_rube_redoFixture.setVertex(5,-0.101466,-0.0506777);
}
{
	fixture _rube_redoFixture = getFixture(36);
	_rube_redoFixture.setVertex(0,-0.138136,0.0360215);
	_rube_redoFixture.setVertex(1,-0.176537,0.053437);
	_rube_redoFixture.setVertex(2,-0.189518,0.0540049);
	_rube_redoFixture.setVertex(3,-0.226864,-0.0122229);
	_rube_redoFixture.setVertex(4,-0.233218,-0.0294221);
}
{
	fixture _rube_redoFixture = getFixture(37);
	_rube_redoFixture.setVertex(0,-0.138136,0.0360215);
	_rube_redoFixture.setVertex(1,-0.233218,-0.0294221);
	_rube_redoFixture.setVertex(2,-0.240574,-0.100166);
	_rube_redoFixture.setVertex(3,-0.192979,-0.108496);
	_rube_redoFixture.setVertex(4,-0.175672,-0.0986516);
	_rube_redoFixture.setVertex(5,-0.147171,-0.0517695);
}
{
	fixture _rube_redoFixture = getFixture(34);
	_rube_redoFixture.setVertex(0,-0.189518,0.0540049);
	_rube_redoFixture.setVertex(1,-0.217208,0.036346);
	_rube_redoFixture.setVertex(2,-0.226864,-0.0122229);
}
{
	fixture _rube_redoFixture = getFixture(35);
	_rube_redoFixture.setVertex(0,-0.233218,-0.0294221);
	_rube_redoFixture.setVertex(1,-0.255285,-0.0501909);
	_rube_redoFixture.setVertex(2,-0.260478,-0.0752867);
	_rube_redoFixture.setVertex(3,-0.240574,-0.100166);
}
getJoint(4).setLocalAnchorB(0.239162,0.0320078);
getImage(3).setCenter(2.5609e-10,1.41724e-08);
getImage(3).setScale(0.223318);
getBody(6).setPosition(0.601785,0.274962);
{
	fixture _rube_redoFixture = getFixture(51);
	_rube_redoFixture.setVertex(0,0.260285,0.063497);
	_rube_redoFixture.setVertex(1,0.254499,0.0986373);
	_rube_redoFixture.setVertex(2,0.243181,0.108669);
	_rube_redoFixture.setVertex(3,0.198169,0.0975709);
	_rube_redoFixture.setVertex(4,0.157496,0.0804798);
	_rube_redoFixture.setVertex(5,0.0917279,0.0365622);
	_rube_redoFixture.setVertex(6,0.0757194,-0.074315);
}
{
	fixture _rube_redoFixture = getFixture(49);
	_rube_redoFixture.setVertex(0,-0.0094662,0.0255964);
	_rube_redoFixture.setVertex(1,-0.0994646,0.0281925);
	_rube_redoFixture.setVertex(2,-0.101466,-0.0506777);
	_rube_redoFixture.setVertex(3,-0.0666888,-0.0604808);
}
{
	fixture _rube_redoFixture = getFixture(50);
	_rube_redoFixture.setVertex(0,0.260285,0.063497);
	_rube_redoFixture.setVertex(1,0.0757194,-0.074315);
	_rube_redoFixture.setVertex(2,0.114228,-0.0759357);
	_rube_redoFixture.setVertex(3,0.146435,-0.0686029);
	_rube_redoFixture.setVertex(4,0.222398,-0.0411046);
	_rube_redoFixture.setVertex(5,0.239922,-0.0237972);
	_rube_redoFixture.setVertex(6,0.25286,0.0155905);
}
{
	fixture _rube_redoFixture = getFixture(48);
	_rube_redoFixture.setVertex(0,0.0917279,0.0365622);
	_rube_redoFixture.setVertex(1,-0.0094662,0.0255964);
	_rube_redoFixture.setVertex(2,-0.0666888,-0.0604808);
	_rube_redoFixture.setVertex(3,0.0757194,-0.074315);
}
{
	fixture _rube_redoFixture = getFixture(46);
	_rube_redoFixture.setVertex(0,-0.138136,0.0360214);
	_rube_redoFixture.setVertex(1,-0.233218,-0.0294222);
	_rube_redoFixture.setVertex(2,-0.240574,-0.100166);
	_rube_redoFixture.setVertex(3,-0.192979,-0.108496);
	_rube_redoFixture.setVertex(4,-0.175672,-0.0986516);
	_rube_redoFixture.setVertex(5,-0.147171,-0.0517696);
}
{
	fixture _rube_redoFixture = getFixture(47);
	_rube_redoFixture.setVertex(0,-0.0994646,0.0281925);
	_rube_redoFixture.setVertex(1,-0.124614,0.0430525);
	_rube_redoFixture.setVertex(2,-0.138136,0.0360214);
	_rube_redoFixture.setVertex(3,-0.147171,-0.0517696);
	_rube_redoFixture.setVertex(4,-0.132619,-0.0620356);
	_rube_redoFixture.setVertex(5,-0.101466,-0.0506777);
}
{
	fixture _rube_redoFixture = getFixture(44);
	_rube_redoFixture.setVertex(0,-0.233218,-0.0294222);
	_rube_redoFixture.setVertex(1,-0.255285,-0.050191);
	_rube_redoFixture.setVertex(2,-0.260478,-0.0752867);
	_rube_redoFixture.setVertex(3,-0.240574,-0.100166);
}
{
	fixture _rube_redoFixture = getFixture(45);
	_rube_redoFixture.setVertex(0,-0.138136,0.0360214);
	_rube_redoFixture.setVertex(1,-0.176537,0.0534369);
	_rube_redoFixture.setVertex(2,-0.189518,0.0540049);
	_rube_redoFixture.setVertex(3,-0.226864,-0.0122229);
	_rube_redoFixture.setVertex(4,-0.233218,-0.0294222);
}
{
	fixture _rube_redoFixture = getFixture(43);
	_rube_redoFixture.setVertex(0,-0.189518,0.0540049);
	_rube_redoFixture.setVertex(1,-0.217208,0.036346);
	_rube_redoFixture.setVertex(2,-0.226864,-0.0122229);
}
setCursor(1.29692, 0.857723);
setCursor(0.00174462, 0.00261896);
getImage(7).setCenter(1.61733,0.491665);
getImage(7).setAngle(0.869212);
setCursor(1.1717, -0.326542);
getImage(7).setCenter(2.08693,-0.152198);
getImage(7).setAngle(-0.014626);
getImage(7).setCenter(1.05294,1.07142);
getImage(7).setCenter(1.06123,1.07024);
getImage(7).setCenter(1.06597,1.07142);
getImage(4).select();
getImage(5).select();
getImage(1).select();
getImage(2).select();
getImage(3).select();
getImage(6).select();
getImage(7).deselect();
getImage(4).deselect();
getImage(5).deselect();
getImage(1).deselect();
getImage(2).deselect();
getImage(3).deselect();
getImage(6).deselect();
getJoint(1).setLocalAnchorB(-0.156434,-0.00840778);
getImage(1).setCenter(7.52903e-07,-1.17969e-07);
getImage(1).setScale(0.149868);
getBody(1).setPosition(0.886574,0.918323);
{
	fixture _rube_redoFixture = getFixture(2);
	_rube_redoFixture.setVertex(0,0.180437,-0.02621);
	_rube_redoFixture.setVertex(1,0.171075,-0.00795633);
	_rube_redoFixture.setVertex(2,0.0875264,0.0466897);
	_rube_redoFixture.setVertex(3,-0.0327189,0.0380748);
	_rube_redoFixture.setVertex(4,-0.0219988,-0.0560493);
	_rube_redoFixture.setVertex(5,0.0607901,-0.0626168);
	_rube_redoFixture.setVertex(6,0.102974,-0.0643566);
	_rube_redoFixture.setVertex(7,0.131993,-0.0576868);
}
{
	fixture _rube_redoFixture = getFixture(1);
	_rube_redoFixture.setVertex(0,-0.147904,0.0755925);
	_rube_redoFixture.setVertex(1,-0.181604,0.0755925);
	_rube_redoFixture.setVertex(2,-0.196817,0.0628523);
	_rube_redoFixture.setVertex(3,-0.181604,0.0561966);
}
{
	fixture _rube_redoFixture = getFixture(4);
	_rube_redoFixture.setVertex(0,0.21794,0.0283177);
	_rube_redoFixture.setVertex(1,0.204776,0.0554663);
	_rube_redoFixture.setVertex(2,0.121696,0.0606142);
	_rube_redoFixture.setVertex(3,0.171075,-0.00795633);
	_rube_redoFixture.setVertex(4,0.198457,-0.00818992);
	_rube_redoFixture.setVertex(5,0.21788,0.00374603);
}
{
	fixture _rube_redoFixture = getFixture(3);
	_rube_redoFixture.setVertex(0,0.171075,-0.00795633);
	_rube_redoFixture.setVertex(1,0.121696,0.0606142);
	_rube_redoFixture.setVertex(2,0.0875264,0.0466897);
}
{
	fixture _rube_redoFixture = getFixture(8);
	_rube_redoFixture.setVertex(0,-0.181604,0.0561966);
	_rube_redoFixture.setVertex(1,-0.214603,0.032765);
	_rube_redoFixture.setVertex(2,-0.217704,0.00743192);
	_rube_redoFixture.setVertex(3,-0.208197,0.0026921);
}
{
	fixture _rube_redoFixture = getFixture(5);
	_rube_redoFixture.setVertex(0,0.180437,-0.02621);
	_rube_redoFixture.setVertex(1,0.131993,-0.0576868);
	_rube_redoFixture.setVertex(2,0.160076,-0.0640063);
	_rube_redoFixture.setVertex(3,0.173181,-0.0552289);
}
{
	fixture _rube_redoFixture = getFixture(7);
	_rube_redoFixture.setVertex(0,-0.0327189,0.0380748);
	_rube_redoFixture.setVertex(1,-0.147904,0.0755925);
	_rube_redoFixture.setVertex(2,-0.181604,0.0561966);
	_rube_redoFixture.setVertex(3,-0.208197,0.0026921);
	_rube_redoFixture.setVertex(4,-0.211414,-0.0272641);
	_rube_redoFixture.setVertex(5,-0.192603,-0.0540588);
}
{
	fixture _rube_redoFixture = getFixture(6);
	_rube_redoFixture.setVertex(0,-0.0219988,-0.0560493);
	_rube_redoFixture.setVertex(1,-0.0327189,0.0380748);
	_rube_redoFixture.setVertex(2,-0.192603,-0.0540588);
	_rube_redoFixture.setVertex(3,-0.170371,-0.0662287);
	_rube_redoFixture.setVertex(4,-0.108588,-0.0755907);
	_rube_redoFixture.setVertex(5,-0.0748881,-0.0755907);
}
getJoint(2).setLocalAnchorB(-0.169446,0.00770358);
getImage(5).setCenter(1.29807e-07,-8.20665e-08);
getImage(5).setScale(0.149868);
getBody(2).setPosition(0.319614,0.915408);
{
	fixture _rube_redoFixture = getFixture(15);
	_rube_redoFixture.setVertex(0,-0.181606,0.0561974);
	_rube_redoFixture.setVertex(1,-0.214604,0.0327645);
	_rube_redoFixture.setVertex(2,-0.217704,0.00743111);
	_rube_redoFixture.setVertex(3,-0.208196,0.00269161);
}
{
	fixture _rube_redoFixture = getFixture(16);
	_rube_redoFixture.setVertex(0,-0.147905,0.075593);
	_rube_redoFixture.setVertex(1,-0.181606,0.0755926);
	_rube_redoFixture.setVertex(2,-0.196817,0.0628534);
	_rube_redoFixture.setVertex(3,-0.181606,0.0561974);
}
{
	fixture _rube_redoFixture = getFixture(13);
	_rube_redoFixture.setVertex(0,-0.021998,-0.0560472);
	_rube_redoFixture.setVertex(1,-0.0327198,0.0380752);
	_rube_redoFixture.setVertex(2,-0.192605,-0.0540597);
	_rube_redoFixture.setVertex(3,-0.170373,-0.0662284);
	_rube_redoFixture.setVertex(4,-0.108588,-0.07559);
	_rube_redoFixture.setVertex(5,-0.0748885,-0.0755892);
}
{
	fixture _rube_redoFixture = getFixture(14);
	_rube_redoFixture.setVertex(0,-0.0327198,0.0380752);
	_rube_redoFixture.setVertex(1,-0.147905,0.075593);
	_rube_redoFixture.setVertex(2,-0.181606,0.0561974);
	_rube_redoFixture.setVertex(3,-0.208196,0.00269161);
	_rube_redoFixture.setVertex(4,-0.211414,-0.0272632);
	_rube_redoFixture.setVertex(5,-0.192605,-0.0540597);
}
{
	fixture _rube_redoFixture = getFixture(12);
	_rube_redoFixture.setVertex(0,0.180436,-0.0262091);
	_rube_redoFixture.setVertex(1,0.131993,-0.0576864);
	_rube_redoFixture.setVertex(2,0.160076,-0.0640046);
	_rube_redoFixture.setVertex(3,0.17318,-0.0552289);
}
{
	fixture _rube_redoFixture = getFixture(10);
	_rube_redoFixture.setVertex(0,0.171076,-0.00795598);
	_rube_redoFixture.setVertex(1,0.121695,0.0606155);
	_rube_redoFixture.setVertex(2,0.0875264,0.04669);
}
{
	fixture _rube_redoFixture = getFixture(11);
	_rube_redoFixture.setVertex(0,0.21794,0.0283184);
	_rube_redoFixture.setVertex(1,0.204775,0.0554659);
	_rube_redoFixture.setVertex(2,0.121695,0.0606155);
	_rube_redoFixture.setVertex(3,0.171076,-0.00795598);
	_rube_redoFixture.setVertex(4,0.198456,-0.00818863);
	_rube_redoFixture.setVertex(5,0.217881,0.00374652);
}
{
	fixture _rube_redoFixture = getFixture(9);
	_rube_redoFixture.setVertex(0,0.180436,-0.0262091);
	_rube_redoFixture.setVertex(1,0.171076,-0.00795598);
	_rube_redoFixture.setVertex(2,0.0875264,0.04669);
	_rube_redoFixture.setVertex(3,-0.0327198,0.0380752);
	_rube_redoFixture.setVertex(4,-0.021998,-0.0560472);
	_rube_redoFixture.setVertex(5,0.0607886,-0.0626158);
	_rube_redoFixture.setVertex(6,0.102973,-0.0643561);
	_rube_redoFixture.setVertex(7,0.131993,-0.0576864);
}
getJoint(6).setLocalAnchorB(-0.247123,-0.0498518);
getImage(6).setCenter(-5.45871e-08,-8.12131e-08);
getImage(6).setScale(0.532397);
getBody(3).setPosition(0.563255,1.23612);
{
	fixture _rube_redoFixture = getFixture(18);
	_rube_redoFixture.setVertex(0,0.253378,-0.149069);
	_rube_redoFixture.setVertex(1,0.240515,-0.0543175);
	_rube_redoFixture.setVertex(2,0.209373,-0.0840638);
	_rube_redoFixture.setVertex(3,0.207536,-0.12084);
	_rube_redoFixture.setVertex(4,0.225861,-0.163943);
}
{
	fixture _rube_redoFixture = getFixture(27);
	_rube_redoFixture.setVertex(0,0.229166,0.030849);
	_rube_redoFixture.setVertex(1,0.202724,0.101362);
	_rube_redoFixture.setVertex(2,0.158653,0.153365);
	_rube_redoFixture.setVertex(3,0.0934294,0.208454);
	_rube_redoFixture.setVertex(4,-0.1226,0.177721);
	_rube_redoFixture.setVertex(5,-0.0195018,-0.266077);
}
{
	fixture _rube_redoFixture = getFixture(25);
	_rube_redoFixture.setVertex(0,-0.0195018,-0.266077);
	_rube_redoFixture.setVertex(1,-0.1226,0.177721);
	_rube_redoFixture.setVertex(2,-0.264122,-0.0707579);
	_rube_redoFixture.setVertex(3,-0.246796,-0.134856);
	_rube_redoFixture.setVertex(4,-0.21826,-0.175732);
	_rube_redoFixture.setVertex(5,-0.0987186,-0.232473);
}
{
	fixture _rube_redoFixture = getFixture(26);
	_rube_redoFixture.setVertex(0,0.240515,-0.0543175);
	_rube_redoFixture.setVertex(1,0.229166,0.030849);
	_rube_redoFixture.setVertex(2,-0.0195018,-0.266077);
	_rube_redoFixture.setVertex(3,0.0264419,-0.254288);
	_rube_redoFixture.setVertex(4,0.0615881,-0.225229);
}
{
	fixture _rube_redoFixture = getFixture(23);
	_rube_redoFixture.setVertex(0,0.0934294,0.208454);
	_rube_redoFixture.setVertex(1,0.024927,0.220353);
	_rube_redoFixture.setVertex(2,-0.120148,0.209996);
	_rube_redoFixture.setVertex(3,-0.1226,0.177721);
}
{
	fixture _rube_redoFixture = getFixture(24);
	_rube_redoFixture.setVertex(0,-0.1226,0.177721);
	_rube_redoFixture.setVertex(1,-0.157553,0.170223);
	_rube_redoFixture.setVertex(2,-0.206251,0.117228);
	_rube_redoFixture.setVertex(3,-0.262193,0.0274336);
	_rube_redoFixture.setVertex(4,-0.264122,-0.0707579);
}
{
	fixture _rube_redoFixture = getFixture(22);
	_rube_redoFixture.setVertex(0,0.024927,0.220353);
	_rube_redoFixture.setVertex(1,0.0138819,0.244151);
	_rube_redoFixture.setVertex(2,-0.0458064,0.263853);
	_rube_redoFixture.setVertex(3,-0.0885824,0.249108);
	_rube_redoFixture.setVertex(4,-0.120148,0.209996);
}
{
	fixture _rube_redoFixture = getFixture(20);
	_rube_redoFixture.setVertex(0,0.264203,-0.0493595);
	_rube_redoFixture.setVertex(1,0.249784,0.000880983);
	_rube_redoFixture.setVertex(2,0.240515,-0.0543175);
}
{
	fixture _rube_redoFixture = getFixture(21);
	_rube_redoFixture.setVertex(0,0.249784,0.000880983);
	_rube_redoFixture.setVertex(1,0.229166,0.030849);
	_rube_redoFixture.setVertex(2,0.240515,-0.0543175);
}
{
	fixture _rube_redoFixture = getFixture(19);
	_rube_redoFixture.setVertex(0,0.209373,-0.0840638);
	_rube_redoFixture.setVertex(1,0.0615881,-0.225229);
	_rube_redoFixture.setVertex(2,0.116346,-0.225973);
	_rube_redoFixture.setVertex(3,0.165705,-0.201844);
	_rube_redoFixture.setVertex(4,0.195673,-0.161299);
	_rube_redoFixture.setVertex(5,0.207536,-0.12084);
}
{
	fixture _rube_redoFixture = getFixture(17);
	_rube_redoFixture.setVertex(0,-0.206251,0.117228);
	_rube_redoFixture.setVertex(1,-0.234897,0.0992687);
	_rube_redoFixture.setVertex(2,-0.262193,0.0274336);
}
getJoint(1).setLocalAnchorA(0.14732,-0.102511);
getJoint(2).setLocalAnchorA(0.136333,0.139197);
getJoint(4).setLocalAnchorA(-0.244907,0.0604036);
getJoint(5).setLocalAnchorA(-0.24605,-0.112284);
getJoint(6).setLocalAnchorA(0.224546,0.0248304);
getImage(2).setCenter(2.18294e-08,-2.05281e-07);
getImage(2).setScale(0.421764);
getBody(4).setPosition(0.627629,0.762595);
{
	fixture _rube_redoFixture = getFixture(33);
	_rube_redoFixture.setVertex(0,0.249677,-0.0785147);
	_rube_redoFixture.setVertex(1,-0.13144,0.160239);
	_rube_redoFixture.setVertex(2,-0.252493,-0.16331);
	_rube_redoFixture.setVertex(3,-0.151644,-0.177442);
	_rube_redoFixture.setVertex(4,0.0808147,-0.152024);
	_rube_redoFixture.setVertex(5,0.195558,-0.111364);
}
{
	fixture _rube_redoFixture = getFixture(32);
	_rube_redoFixture.setVertex(0,-0.13144,0.160239);
	_rube_redoFixture.setVertex(1,-0.185741,0.140203);
	_rube_redoFixture.setVertex(2,-0.266678,0.068195);
	_rube_redoFixture.setVertex(3,-0.274378,-0.0263588);
	_rube_redoFixture.setVertex(4,-0.252493,-0.16331);
}
{
	fixture _rube_redoFixture = getFixture(30);
	_rube_redoFixture.setVertex(0,0.249677,-0.0785147);
	_rube_redoFixture.setVertex(1,0.195558,-0.111364);
	_rube_redoFixture.setVertex(2,0.216252,-0.109247);
}
{
	fixture _rube_redoFixture = getFixture(31);
	_rube_redoFixture.setVertex(0,0.256435,-0.00594516);
	_rube_redoFixture.setVertex(1,0.249003,0.0677463);
	_rube_redoFixture.setVertex(2,0.215354,0.131006);
	_rube_redoFixture.setVertex(3,0.174078,0.148504);
	_rube_redoFixture.setVertex(4,0.0915544,0.168028);
	_rube_redoFixture.setVertex(5,-0.0468832,0.174918);
	_rube_redoFixture.setVertex(6,-0.13144,0.160239);
	_rube_redoFixture.setVertex(7,0.249677,-0.0785147);
}
{
	fixture _rube_redoFixture = getFixture(28);
	_rube_redoFixture.setVertex(0,-0.185741,0.140203);
	_rube_redoFixture.setVertex(1,-0.222531,0.139419);
	_rube_redoFixture.setVertex(2,-0.252973,0.116608);
	_rube_redoFixture.setVertex(3,-0.266678,0.068195);
}
{
	fixture _rube_redoFixture = getFixture(29);
	_rube_redoFixture.setVertex(0,-0.151644,-0.177442);
	_rube_redoFixture.setVertex(1,-0.252493,-0.16331);
	_rube_redoFixture.setVertex(2,-0.231507,-0.186297);
	_rube_redoFixture.setVertex(3,-0.19292,-0.190005);
}
getJoint(5).setLocalAnchorB(0.240863,0.0390053);
getImage(4).setCenter(1.03275e-08,1.93541e-09);
getImage(4).setScale(0.224264);
getBody(5).setPosition(0.778918,0.275682);
{
	fixture _rube_redoFixture = getFixture(41);
	_rube_redoFixture.setVertex(0,0.261389,0.0637662);
	_rube_redoFixture.setVertex(1,0.0760404,-0.07463);
	_rube_redoFixture.setVertex(2,0.114712,-0.0762576);
	_rube_redoFixture.setVertex(3,0.147056,-0.0688936);
	_rube_redoFixture.setVertex(4,0.223341,-0.0412789);
	_rube_redoFixture.setVertex(5,0.240939,-0.0238981);
	_rube_redoFixture.setVertex(6,0.253932,0.0156567);
}
{
	fixture _rube_redoFixture = getFixture(42);
	_rube_redoFixture.setVertex(0,0.261389,0.0637662);
	_rube_redoFixture.setVertex(1,0.255578,0.0990555);
	_rube_redoFixture.setVertex(2,0.244212,0.109129);
	_rube_redoFixture.setVertex(3,0.199009,0.0979845);
	_rube_redoFixture.setVertex(4,0.158164,0.080821);
	_rube_redoFixture.setVertex(5,0.0921168,0.0367173);
	_rube_redoFixture.setVertex(6,0.0760404,-0.07463);
}
{
	fixture _rube_redoFixture = getFixture(39);
	_rube_redoFixture.setVertex(0,0.0921168,0.0367173);
	_rube_redoFixture.setVertex(1,-0.00950634,0.0257049);
	_rube_redoFixture.setVertex(2,-0.0669715,-0.0607371);
	_rube_redoFixture.setVertex(3,0.0760404,-0.07463);
}
{
	fixture _rube_redoFixture = getFixture(40);
	_rube_redoFixture.setVertex(0,-0.00950634,0.0257049);
	_rube_redoFixture.setVertex(1,-0.0998862,0.0283121);
	_rube_redoFixture.setVertex(2,-0.101896,-0.0508925);
	_rube_redoFixture.setVertex(3,-0.0669715,-0.0607371);
}
{
	fixture _rube_redoFixture = getFixture(38);
	_rube_redoFixture.setVertex(0,-0.0998862,0.0283121);
	_rube_redoFixture.setVertex(1,-0.125143,0.0432351);
	_rube_redoFixture.setVertex(2,-0.138722,0.0361742);
	_rube_redoFixture.setVertex(3,-0.147795,-0.051989);
	_rube_redoFixture.setVertex(4,-0.133181,-0.0622986);
	_rube_redoFixture.setVertex(5,-0.101896,-0.0508925);
}
{
	fixture _rube_redoFixture = getFixture(36);
	_rube_redoFixture.setVertex(0,-0.138722,0.0361742);
	_rube_redoFixture.setVertex(1,-0.177285,0.0536636);
	_rube_redoFixture.setVertex(2,-0.190321,0.0542339);
	_rube_redoFixture.setVertex(3,-0.227825,-0.0122747);
	_rube_redoFixture.setVertex(4,-0.234207,-0.0295468);
}
{
	fixture _rube_redoFixture = getFixture(37);
	_rube_redoFixture.setVertex(0,-0.138722,0.0361742);
	_rube_redoFixture.setVertex(1,-0.234207,-0.0295468);
	_rube_redoFixture.setVertex(2,-0.241593,-0.100591);
	_rube_redoFixture.setVertex(3,-0.193797,-0.108955);
	_rube_redoFixture.setVertex(4,-0.176416,-0.0990698);
	_rube_redoFixture.setVertex(5,-0.147795,-0.051989);
}
{
	fixture _rube_redoFixture = getFixture(34);
	_rube_redoFixture.setVertex(0,-0.190321,0.0542339);
	_rube_redoFixture.setVertex(1,-0.218129,0.0365);
	_rube_redoFixture.setVertex(2,-0.227825,-0.0122747);
}
{
	fixture _rube_redoFixture = getFixture(35);
	_rube_redoFixture.setVertex(0,-0.234207,-0.0295468);
	_rube_redoFixture.setVertex(1,-0.256367,-0.0504036);
	_rube_redoFixture.setVertex(2,-0.261582,-0.0756058);
	_rube_redoFixture.setVertex(3,-0.241593,-0.100591);
}
getJoint(4).setLocalAnchorB(0.240176,0.0321435);
getImage(3).setCenter(5.31914e-10,-2.90395e-08);
getImage(3).setScale(0.224264);
getBody(6).setPosition(0.599369,0.277512);
{
	fixture _rube_redoFixture = getFixture(51);
	_rube_redoFixture.setVertex(0,0.261389,0.0637661);
	_rube_redoFixture.setVertex(1,0.255578,0.0990554);
	_rube_redoFixture.setVertex(2,0.244212,0.109129);
	_rube_redoFixture.setVertex(3,0.199009,0.0979845);
	_rube_redoFixture.setVertex(4,0.158164,0.0808209);
	_rube_redoFixture.setVertex(5,0.0921168,0.0367172);
	_rube_redoFixture.setVertex(6,0.0760404,-0.07463);
}
{
	fixture _rube_redoFixture = getFixture(49);
	_rube_redoFixture.setVertex(0,-0.00950634,0.0257049);
	_rube_redoFixture.setVertex(1,-0.0998862,0.028312);
	_rube_redoFixture.setVertex(2,-0.101896,-0.0508925);
	_rube_redoFixture.setVertex(3,-0.0669715,-0.0607372);
}
{
	fixture _rube_redoFixture = getFixture(50);
	_rube_redoFixture.setVertex(0,0.261389,0.0637661);
	_rube_redoFixture.setVertex(1,0.0760404,-0.07463);
	_rube_redoFixture.setVertex(2,0.114712,-0.0762576);
	_rube_redoFixture.setVertex(3,0.147056,-0.0688937);
	_rube_redoFixture.setVertex(4,0.223341,-0.0412789);
	_rube_redoFixture.setVertex(5,0.240939,-0.0238981);
	_rube_redoFixture.setVertex(6,0.253932,0.0156566);
}
{
	fixture _rube_redoFixture = getFixture(48);
	_rube_redoFixture.setVertex(0,0.0921168,0.0367172);
	_rube_redoFixture.setVertex(1,-0.00950634,0.0257049);
	_rube_redoFixture.setVertex(2,-0.0669715,-0.0607372);
	_rube_redoFixture.setVertex(3,0.0760404,-0.07463);
}
{
	fixture _rube_redoFixture = getFixture(46);
	_rube_redoFixture.setVertex(0,-0.138722,0.0361741);
	_rube_redoFixture.setVertex(1,-0.234207,-0.0295469);
	_rube_redoFixture.setVertex(2,-0.241593,-0.100591);
	_rube_redoFixture.setVertex(3,-0.193797,-0.108956);
	_rube_redoFixture.setVertex(4,-0.176416,-0.0990698);
	_rube_redoFixture.setVertex(5,-0.147795,-0.051989);
}
{
	fixture _rube_redoFixture = getFixture(47);
	_rube_redoFixture.setVertex(0,-0.0998862,0.028312);
	_rube_redoFixture.setVertex(1,-0.125143,0.043235);
	_rube_redoFixture.setVertex(2,-0.138722,0.0361741);
	_rube_redoFixture.setVertex(3,-0.147795,-0.051989);
	_rube_redoFixture.setVertex(4,-0.133181,-0.0622986);
	_rube_redoFixture.setVertex(5,-0.101896,-0.0508925);
}
{
	fixture _rube_redoFixture = getFixture(44);
	_rube_redoFixture.setVertex(0,-0.234207,-0.0295469);
	_rube_redoFixture.setVertex(1,-0.256367,-0.0504037);
	_rube_redoFixture.setVertex(2,-0.261582,-0.0756058);
	_rube_redoFixture.setVertex(3,-0.241593,-0.100591);
}
{
	fixture _rube_redoFixture = getFixture(45);
	_rube_redoFixture.setVertex(0,-0.138722,0.0361741);
	_rube_redoFixture.setVertex(1,-0.177285,0.0536634);
	_rube_redoFixture.setVertex(2,-0.190321,0.0542339);
	_rube_redoFixture.setVertex(3,-0.227825,-0.0122747);
	_rube_redoFixture.setVertex(4,-0.234207,-0.0295469);
}
{
	fixture _rube_redoFixture = getFixture(43);
	_rube_redoFixture.setVertex(0,-0.190321,0.0542339);
	_rube_redoFixture.setVertex(1,-0.218129,0.0365001);
	_rube_redoFixture.setVertex(2,-0.227825,-0.0122747);
}
getImage(7).select();
