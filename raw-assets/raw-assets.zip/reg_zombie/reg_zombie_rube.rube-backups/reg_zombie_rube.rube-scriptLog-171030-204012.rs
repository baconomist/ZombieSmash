//Restarted script log at 10/30/17 20:40:12
