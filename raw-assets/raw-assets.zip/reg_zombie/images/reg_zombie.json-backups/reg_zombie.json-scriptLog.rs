//Started script log at 08/23/17 10:51:53

