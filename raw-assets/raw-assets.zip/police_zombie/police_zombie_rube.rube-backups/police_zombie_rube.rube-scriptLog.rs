//Started script log at 11/25/17 16:14:50

