//Restarted script log at 11/10/17 22:00:24
