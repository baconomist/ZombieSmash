//Started script log at 11/21/17 20:42:04

getFixture(3).select();
getFixture(3).deselect();
getFixture(1).select();
getFixture(1).deselect();
getFixture(4).select();
getFixture(4).deselect();
getFixture(2).select();
